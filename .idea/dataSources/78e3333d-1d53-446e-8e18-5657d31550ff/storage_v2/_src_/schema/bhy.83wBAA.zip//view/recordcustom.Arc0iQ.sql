create view recordcustom as
  select `bhy`.`record`.`r_id`      AS `r_id`,
         `bhy`.`record`.`cl_id`     AS `cl_id`,
         `bhy`.`record`.`st_id`     AS `st_id`,
         `bhy`.`record`.`c_id`      AS `c_id`,
         `bhy`.`record`.`r_time`    AS `r_time`,
         `bhy`.`record`.`r_price`   AS `r_price`,
         `bhy`.`record`.`r_num`     AS `r_num`,
         `bhy`.`record`.`r_pattern` AS `r_pattern`,
         `bhy`.`client`.`cl_name`   AS `cl_name`,
         `bhy`.`store`.`s_address`  AS `s_address`,
         `bhy`.`cargo`.`c_name`     AS `c_name`
  from (((`bhy`.`record` left join `bhy`.`client` on ((`bhy`.`record`.`cl_id` =
                                                       `bhy`.`client`.`cl_id`))) left join `bhy`.`store` on ((
    `bhy`.`record`.`st_id` = `bhy`.`store`.`st_id`))) left join `bhy`.`cargo` on ((`bhy`.`record`.`c_id` =
                                                                                   `bhy`.`cargo`.`c_id`)));

-- comment on view recordcustom not supported: View 'bhy.cargocustom' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them

