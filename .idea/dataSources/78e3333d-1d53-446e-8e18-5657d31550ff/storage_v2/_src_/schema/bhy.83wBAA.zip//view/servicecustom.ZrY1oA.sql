create view servicecustom as
  select `bhy`.`service`.`s_id`        AS `s_id`,
         `bhy`.`service`.`p_id`        AS `p_id`,
         `bhy`.`service`.`s_isdispose` AS `s_isdispose`,
         `bhy`.`service`.`s_isfinish`  AS `s_isfinish`,
         `bhy`.`service`.`d_id`        AS `d_id`,
         `bhy`.`service`.`e_id`        AS `e_id`,
         `bhy`.`service`.`s_atime`     AS `s_atime`,
         `bhy`.`service`.`s_price`     AS `s_price`,
         `bhy`.`dictionary`.`d_value`  AS `d_value`,
         `bhy`.`employee`.`e_name`     AS `e_name`
  from ((`bhy`.`service` left join `bhy`.`dictionary` on ((`bhy`.`service`.`d_id` =
                                                           `bhy`.`dictionary`.`d_id`))) left join `bhy`.`employee` on ((
    `bhy`.`service`.`e_id` = `bhy`.`employee`.`e_id`)));

