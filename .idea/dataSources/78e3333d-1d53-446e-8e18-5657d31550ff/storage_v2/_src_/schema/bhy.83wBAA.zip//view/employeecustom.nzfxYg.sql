create view employeecustom as
  select `bhy`.`employee`.`e_id`      AS `e_id`,
         `bhy`.`employee`.`e_name`    AS `e_name`,
         `bhy`.`employee`.`e_salary`  AS `e_salary`,
         `bhy`.`employee`.`st_id`     AS `st_id`,
         `bhy`.`employee`.`d_id`      AS `d_id`,
         `bhy`.`employee`.`u_id`      AS `u_id`,
         `bhy`.`employee`.`e_sex`     AS `e_sex`,
         `bhy`.`employee`.`e_age`     AS `e_age`,
         `bhy`.`employee`.`e_time`    AS `e_time`,
         `bhy`.`store`.`s_address`    AS `s_address`,
         `bhy`.`dictionary`.`d_value` AS `d_value`,
         `bhy`.`user`.`username`      AS `username`
  from (((`bhy`.`employee` left join `bhy`.`store` on ((`bhy`.`employee`.`st_id` =
                                                        `bhy`.`store`.`st_id`))) left join `bhy`.`dictionary` on ((
    `bhy`.`employee`.`d_id` = `bhy`.`dictionary`.`d_id`))) left join `bhy`.`user` on ((`bhy`.`employee`.`u_id` =
                                                                                       `bhy`.`user`.`u_id`)));

-- comment on view employeecustom not supported: View 'bhy.cargocustom' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them

