create view storecustom as
  select `bhy`.`store`.`st_id`        AS `st_id`,
         `bhy`.`store`.`d_id`         AS `d_id`,
         `bhy`.`store`.`e_id`         AS `e_id`,
         `bhy`.`store`.`s_address`    AS `s_address`,
         `bhy`.`store`.`st_time`      AS `st_time`,
         `bhy`.`dictionary`.`d_value` AS `d_value`,
         `bhy`.`employee`.`e_name`    AS `e_name`
  from ((`bhy`.`store` left join `bhy`.`dictionary` on ((`bhy`.`store`.`d_id` =
                                                         `bhy`.`dictionary`.`d_id`))) left join `bhy`.`employee` on ((
    `bhy`.`store`.`e_id` = `bhy`.`employee`.`e_id`)));

-- comment on view storecustom not supported: View 'bhy.cargocustom' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them

