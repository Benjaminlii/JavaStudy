create view petcustom as
  select `bhy`.`pet`.`p_id`           AS `p_id`,
         `bhy`.`pet`.`cl_id`          AS `cl_id`,
         `bhy`.`pet`.`d_id`           AS `d_id`,
         `bhy`.`pet`.`s_id`           AS `s_id`,
         `bhy`.`pet`.`p_age`          AS `p_age`,
         `bhy`.`pet`.`p_sex`          AS `p_sex`,
         `bhy`.`pet`.`p_height`       AS `p_height`,
         `bhy`.`pet`.`p_healthy`      AS `p_healthy`,
         `bhy`.`client`.`cl_name`     AS `cl_name`,
         `bhy`.`dictionary`.`d_value` AS `d_value`,
         `bhy`.`store`.`s_address`    AS `s_address`
  from (((`bhy`.`pet` left join `bhy`.`client` on ((`bhy`.`pet`.`cl_id` =
                                                    `bhy`.`client`.`cl_id`))) left join `bhy`.`dictionary` on ((
    `bhy`.`pet`.`d_id` = `bhy`.`dictionary`.`d_id`))) left join `bhy`.`store` on ((`bhy`.`pet`.`s_id` =
                                                                                   `bhy`.`store`.`st_id`)));

-- comment on view petcustom not supported: View 'bhy.cargocustom' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them

