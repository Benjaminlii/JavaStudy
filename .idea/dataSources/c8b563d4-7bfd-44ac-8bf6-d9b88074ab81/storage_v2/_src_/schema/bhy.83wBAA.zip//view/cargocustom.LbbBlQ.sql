create view cargocustom as
  select `bhy`.`cargo`.`c_id`             AS `c_id`,
         `bhy`.`cargo`.`c_name`           AS `c_name`,
         `bhy`.`cargo`.`c_num`            AS `c_num`,
         `bhy`.`cargo`.`d_id`             AS `d_id`,
         `bhy`.`cargo`.`s_id`             AS `s_id`,
         `bhy`.`cargo`.`c_getdate`        AS `c_getdate`,
         `bhy`.`cargo`.`c_produceddate`   AS `c_produceddate`,
         `bhy`.`cargo`.`c_expirationdate` AS `c_expirationdate`,
         `bhy`.`dictionary`.`d_value`     AS `d_value`,
         `bhy`.`store`.`s_address`        AS `s_address`
  from ((`bhy`.`cargo` left join `bhy`.`dictionary` on ((`bhy`.`cargo`.`d_id` =
                                                         `bhy`.`dictionary`.`d_id`))) left join `bhy`.`store` on ((
    `bhy`.`cargo`.`s_id` = `bhy`.`store`.`st_id`)));

-- comment on view cargocustom not supported: View 'bhy.cargocustom' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them

